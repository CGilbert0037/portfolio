(function () {
  'use strict';

  var gulp = require('gulp'),
      $ = require('gulp-load-plugins')({
          pattern: ['gulp-*']
      }),
      browserSync = require('browser-sync'),

      paths = {
        scss: [
          'styles/scss/**/**/*.scss',
          'styles/scss/**/*/scss',
          'styles/scss/*.scss'
        ]
      };

    function scss() {
      return gulp.src(paths.scss)
      .pipe($.sass({ outputStyle: 'compressed' }).on('error', errorHandler('Sass')))
      .pipe($.autoprefixer()).on('error', errorHandler('Autoprefixer'))
      .pipe($.rename({ suffix: '.min' }))
      .pipe($.sourcemaps.write())
      .pipe(gulp.dest('styles/css'));
    }

    function scssReload() {
        return scss()
            .pipe(browserSync.stream());
    }

    function serve() {
        browserSync({
            // notify: true,
            // open: true,
            //logLevel: 'debug',
            port: 40432,
            server: {
                baseDir: ""
            }
            // ,
            // scriptPath: function (path, port, options) {
            //     return options.get("absolute");
            // }
        });
        gulp.watch(paths.scss, scssReload);
        gulp.watch('*.html').on('change', browserSync.reload);
    }

    gulp.task('default', gulp.parallel(scss));
    gulp.task('serve', gulp.series('default', serve));

    // ERROR HANDLER
    function errorHandler(title) {
        return function (err) {
            $.util.log($.util.colors.red('[' + title + ']'), err.toString());
            this.emit('end');
        };
    }

}());
