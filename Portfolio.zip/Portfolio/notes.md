Portfolio Website Challenge

navbar
[] Make a nav-bar
[] Include list ellements
[] Make it fixed position
